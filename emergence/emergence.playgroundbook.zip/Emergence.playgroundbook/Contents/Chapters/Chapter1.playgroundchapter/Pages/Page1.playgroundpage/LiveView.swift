import PlaygroundSupport
import UIKit

let rVc = RulesViewController()
PlaygroundPage.current.liveView = rVc

